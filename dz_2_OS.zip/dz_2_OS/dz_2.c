#include <time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include "semaphore.h"
#include <signal.h>
#include <stdbool.h>
#include <sys/wait.h>

#define N 5    

#define MAX_COUNT 100 
#define MAX_COUNT_IN_POT 10



pid_t child_pids[MAX_COUNT];


char shared_memory_name[] = "semaphore_library";   
int memory_fd; 					

char sem_name[] = "semaphore_library";		   
sem_t *semaphore_adress; 	


typedef struct {
    int count;
    bool is_sleep;
} bear;

bear* bears;


void closing(int id) {
  sem_close(semaphore_adress);
  shm_unlink(shared_memory_name);
  exit(-1);
}

int main(){
    signal(SIGINT,closing);
    signal(SIGTERM,closing);
    signal(SIGQUIT,closing);
    
    int num_bees;			
    do{
    	printf("write number of bees (>=1 and <= %d) \n", MAX_COUNT);
    	scanf("%d", & num_bees);	
    } while(num_bees < 1 || num_bees > MAX_COUNT);
    
   
    
    // creating semaphore
    if((semaphore_adress = sem_open(sem_name, O_CREAT, 0666, 1)) == 0) {
        perror("Can not create posix semaphore");
        exit(-1);
    };

    
    // shared memory
      shm_unlink(shared_memory_name);
    if ((memory_fd = shm_open(shared_memory_name, O_CREAT | O_EXCL | O_RDWR, 0666)) == -1) {
	perror("Can not create shared memory");
	exit(-1);
    } else {
        printf("shared memory created: %s \n", shared_memory_name);
    }
    
    if (ftruncate(memory_fd, sizeof(bear)) == -1) {
        printf("Memory sizing error\n");
        perror("ftruncate");
        return 1;
    } else {
        printf("memory created with size %ld\n", sizeof(bear));
    }
    bears = mmap(0, sizeof (bear), PROT_READ|PROT_WRITE, MAP_SHARED, memory_fd, 0);
    
    bears->count = 0;
    bears->is_sleep = true;
    
    
    // start cycle of booking books
    for(int i = 0; i < num_bees; i++){
    	int result = fork();
    	
    	if (result < 0){
    	    printf("something wrong with fork");
    	    exit(-1);
    	} else if (result == 0){
    	    srand(time(NULL));
      	    bears = mmap(0, sizeof (bear), PROT_READ|PROT_WRITE, MAP_SHARED, memory_fd, 0);
      	    
      	    int* count = &bears->count;
            bool* is_sleep = &bears->is_sleep;
      	    
      	    while(true){
      	         
      	  	if(sem_wait(semaphore_adress) == -1) {
               	    perror("error wait of posix semaphore");
                    exit(-1);
          	};
            
            	 
            	if (*is_sleep){
            	    printf("count in pot %d \n", *count);
            	    *count+= 1;
                    if(*count == MAX_COUNT_IN_POT){
                      *count = 0;
                      *is_sleep = false;
                      printf("bear woke up \n");
                      sleep(2);
                      *is_sleep = true;
                     }
            	}
            	
            	if(sem_post(semaphore_adress) == -1) {
               	    perror("error post of posix semaphore");
                    exit(-1);
          	};	
      	    }
      	    
      	    sleep(1);
      	    
      	    
      	    close(memory_fd);
      	    exit(0);      
    	}
    	sleep(1);
    	child_pids[i] = result;
    }
  for(;;) {
  }
  for(int i= 0;i<num_bees;++i){
  	int status;
  	waitpid(child_pids[i],&status,0);
  }
  if(sem_close(semaphore_adress) == -1) {
        perror("sem_close: Incorrect close of reader semaphore");
  };
  if(sem_unlink(sem_name) == -1) {
        perror("sem_unlink: Incorrect unlink of reader semaphore");
  };
  if (shm_unlink(shared_memory_name) == -1){
    	perror("Cannot close shared memory");
    	exit(-1);
  }
  return 0;
    
}
